import React, { Component, Fragment, body, div } from "react";
import Header from "./components/Header";
import Home from "./components/Home";

class App extends Component {
  render() {
    return (
      // <body>
      //   <h1>Hello, world!</h1>,
      //   </body>
      <Fragment>
        <Header />
        alsdlasjdoiasjdas
        <Home />
      </Fragment>
    );
  }
}

export default App;